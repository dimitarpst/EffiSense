﻿using EffiSense.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OpenAI_API;
using OpenAI_API.Chat;
using System.Diagnostics;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration; // Crucial for _configuration
using System;                            // For Random, DateTime etc.
using System.Collections.Generic;      // For List<T>
using System.Linq;                       // For .Any(), .OrderBy() etc.
using System.Threading.Tasks;          // For Task, async/await

namespace EffiSense.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context, UserManager<ApplicationUser> userManager, IConfiguration configuration)
        {
            _logger = logger;
            _context = context;
            _userManager = userManager;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public async Task<IActionResult> GetCategoryData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            var categoryData = _context.Usages
                .Include(u => u.Appliance)
                .Where(u => u.UserId == user.Id)
                .GroupBy(u => u.Appliance.Name)
                .Select(g => new
                {
                    Appliance = g.Key,
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .ToList();

            var labels = categoryData.Select(d => d.Appliance).ToArray();
            var energyUsed = categoryData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { labels, energyUsed });
        }

        [HttpGet]
        public async Task<IActionResult> GetDayOfWeekData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var usages = await _context.Usages
                .Where(u => u.UserId == user.Id)
                .ToListAsync(); // ✅ Force in-memory evaluation

            var dayOfWeekData = usages
                .GroupBy(u => u.Date.DayOfWeek)
                .Select(g => new
                {
                    DayOfWeek = g.Key.ToString(),
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .ToList();

            var daysOfWeek = dayOfWeekData.Select(d => d.DayOfWeek).ToArray();
            var energyUsed = dayOfWeekData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { daysOfWeek, energyUsed });

        }



        [HttpGet]
        public async Task<IActionResult> GetMonthlyUsageData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var usages = await _context.Usages
                .Where(u => u.UserId == user.Id)
                .ToListAsync(); // ✅ Forces in-memory processing

            var monthlyUsageData = usages
                .GroupBy(u => new { u.Date.Year, u.Date.Month })
                .Select(g => new
                {
                    Month = $"{g.Key.Month}/{g.Key.Year}",
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .OrderBy(d => d.Month)
                .ToList();

            var months = monthlyUsageData.Select(d => d.Month).ToArray();
            var energyUsed = monthlyUsageData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { months, energyUsed });
        }


        [HttpGet]
        public async Task<IActionResult> GetBuildingTypeData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var buildingData = _context.Usages
                .Include(u => u.Appliance)
                .ThenInclude(a => a.Home)
                .Where(u => u.UserId == user.Id)
                .GroupBy(u => u.Appliance.Home.BuildingType)
                .Select(g => new
                {
                    BuildingType = g.Key,
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .ToList();

            var buildingTypes = buildingData.Select(d => d.BuildingType).ToArray();
            var energyUsed = buildingData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { buildingTypes, energyUsed });
        }


        [HttpGet]
        public async Task<IActionResult> GetApplianceData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var userId = user.Id;

            var applianceData = _context.Usages
                .Where(u => u.UserId == userId)
                .GroupBy(u => u.Appliance.Name)
                .Select(g => new
                {
                    ApplianceName = g.Key,
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .ToList();

            var applianceNames = applianceData.Select(d => d.ApplianceName).ToArray();
            var energyUsed = applianceData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { applianceNames, energyUsed });
        }

        [HttpGet]
        public async Task<IActionResult> GetHomeData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var homeData = _context.Usages
                .Include(u => u.Appliance)
                .ThenInclude(a => a.Home)
                .Where(u => u.UserId == user.Id)
                .GroupBy(u => u.Appliance.Home.HouseName)
                .Select(g => new
                {
                    HomeName = g.Key,
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .ToList();

            var homeNames = homeData.Select(d => d.HomeName).ToArray();
            var energyUsed = homeData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { homeNames, energyUsed });
        }

        [HttpGet]
        public async Task<IActionResult> GetPeakTimeData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var peakTimeData = _context.Usages
                .Where(u => u.UserId == user.Id)
                .GroupBy(u => u.Time.Hour)
                .Select(g => new
                {
                    Hour = g.Key,
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .OrderBy(g => g.Hour)
                .ToList();

            var hours = peakTimeData.Select(d => $"{d.Hour}:00").ToArray();
            var energyUsed = peakTimeData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { hours, energyUsed });
        }

        [HttpGet]
        public async Task<IActionResult> GetUsageData()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized(); 
            }

            var userId = user.Id;

            var usageData = _context.Usages
                .Where(u => u.UserId == userId)
                .GroupBy(u => u.Date.Date)
                .Select(g => new
                {
                    Date = g.Key.ToString("yyyy-MM-dd"),
                    EnergyUsed = g.Sum(u => u.EnergyUsed)
                })
                .ToList();

            var labels = usageData.Select(d => d.Date).ToArray();
            var energyUsed = usageData.Select(d => d.EnergyUsed).ToArray();

            return Json(new { labels, energyUsed });
        }

        [HttpPost]
        public async Task<IActionResult> FillDatabase()
        {
            try // Add this
            {
                var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            var random = new Random();
            var currentUtcTime = DateTime.UtcNow;

            // Clear existing data for the user
            var userHomes = _context.Homes.Where(h => h.UserId == user.Id);
            if (await userHomes.AnyAsync())
            {
                var homeIds = await userHomes.Select(h => h.HomeId).ToListAsync();
                var userAppliances = _context.Appliances.Where(a => homeIds.Contains(a.HomeId));
                var applianceIds = await userAppliances.Select(a => a.ApplianceId).ToListAsync();
                var userUsages = _context.Usages.Where(u => u.UserId == user.Id && applianceIds.Contains(u.ApplianceId)); // Ensure UserId match for Usages as well

                _context.Usages.RemoveRange(userUsages);
                _context.Appliances.RemoveRange(userAppliances);
                _context.Homes.RemoveRange(userHomes);
                await _context.SaveChangesAsync();
            }

            // --- START: AI Content Generation Prompts ---
            string homeNamesPrompt = "Generate 20 unique Bulgarian-themed home names.";
            string applianceNamesPrompt = "Generate 50 unique names for household appliances.";
            string applianceBrandsPrompt = "Generate 10 unique brand names for household appliances.";

            string homeDescriptionsPrompt = "Generate 15 unique and imaginative descriptions for homes. Each description should be detailed, ranging from 5 to 9 sentences. Include aspects like architectural style, interior mood, unique features, garden, view, and potential lifestyle. Each description on a new line. For example, 'This sun-drenched Bauhaus villa boasts panoramic ocean views and an infinity pool, offering a serene escape with minimalist luxury.'";
            string applianceNotesPrompt = "Generate 20 unique sets of notes for various household appliances. Each note should be 4 to 8 sentences long. The notes can detail observations on performance, age, interesting quirks, maintenance history, smart features, or user experiences. Each note on a new line. For example, 'The vintage refrigerator hums a gentle tune, a testament to its robust 1950s engineering, though its freezer compartment occasionally needs manual defrosting.'";
            string usageContextNotesPrompt = "Generate 20 unique contextual narratives for energy usage records, each 3 to 7 sentences long. These should describe a scenario or reason for a particular energy consumption pattern. Each narrative on a new line. For example, 'The spike in energy use on Tuesday evening was due to hosting a movie marathon for friends; the large TV, surround sound system, and popcorn maker were all running for several hours.'";
            // --- END: AI Content Generation Prompts ---

            // --- START: Fetching AI Generated Content ---
            _logger.LogInformation("Attempting to generate data with AI...");
            var homeNames = await GenerateDataWithAI(homeNamesPrompt, 200);
            var applianceNames = await GenerateDataWithAI(applianceNamesPrompt, 400); // Increased tokens for more names
            var applianceBrands = await GenerateDataWithAI(applianceBrandsPrompt, 150);

            var aiHomeDescriptions = await GenerateDataWithAI(homeDescriptionsPrompt, 2000); // Significantly increased tokens
            var aiApplianceNotes = await GenerateDataWithAI(applianceNotesPrompt, 2000);     // Significantly increased tokens
            var aiUsageContextNotes = await GenerateDataWithAI(usageContextNotesPrompt, 1500); // Significantly increased tokens
            _logger.LogInformation($"AI Data: Homes({homeNames.Count}), Appliances({applianceNames.Count}), Brands({applianceBrands.Count}), HomeDesc({aiHomeDescriptions.Count}), AppNotes({aiApplianceNotes.Count}), UsageNotes({aiUsageContextNotes.Count})");
            // --- END: Fetching AI Generated Content ---

            // Shuffle generated lists
            homeNames = homeNames.Any() ? homeNames.OrderBy(x => random.Next()).ToList() : new List<string> { "Default Home Name" };
            applianceNames = applianceNames.Any() ? applianceNames.OrderBy(x => random.Next()).ToList() : new List<string> { "Default Appliance Name" };
            applianceBrands = applianceBrands.Any() ? applianceBrands.OrderBy(x => random.Next()).ToList() : new List<string> { "Default Brand" };
            aiHomeDescriptions = aiHomeDescriptions.Any() ? aiHomeDescriptions.OrderBy(x => random.Next()).ToList() : new List<string> { "Charming and well-maintained property with modern amenities and a spacious backyard, perfect for families or entertaining guests. Features an updated kitchen, hardwood floors throughout, and plenty of natural light. Located in a quiet, friendly neighborhood with easy access to parks and local shops." };
            aiApplianceNotes = aiApplianceNotes.Any() ? aiApplianceNotes.OrderBy(x => random.Next()).ToList() : new List<string> { "This appliance has been a reliable workhorse for several years. While it shows some minor cosmetic wear, its performance remains top-notch. Regular cleaning has kept it in good condition, and it operates efficiently for its age. The user manual was misplaced, but online resources are readily available for troubleshooting." };
            aiUsageContextNotes = aiUsageContextNotes.Any() ? aiUsageContextNotes.OrderBy(x => random.Next()).ToList() : new List<string> { "Energy consumption was higher than average this period due to the extended holiday weekend when more family members were home. Several appliances were used more frequently, including the oven for baking and the entertainment system. We also had guests staying over, which contributed to increased lighting and climate control usage." };


            // --- START: Predefined data for other fields ---
            var efficiencyRatings = new List<string?> { "A+++", "A++", "A+", "A", "B", "C", "Energy Star", null };
            var materialDesignApplianceIcons = new List<string?>
            {
                "mdi mdi-television", "mdi mdi-lightbulb-on", "mdi mdi-fridge",
                "mdi mdi-air-conditioner", "mdi mdi-microwave", "mdi mdi-desktop-classic",
                "mdi mdi-washing-machine", "mdi mdi-dishwasher", "mdi mdi-vacuum",
                "mdi mdi-toaster-oven", "mdi mdi-fan", "mdi mdi-water-boiler", null
            };
            // --- END: Predefined data for other fields ---

            int homeCount = random.Next(10, 21); // e.g., 10 to 20 homes
            var homes = new List<Home>();

            for (int i = 0; i < homeCount; i++)
            {
                homes.Add(new Home
                {
                    UserId = user.Id,
                    HouseName = homeNames[i % homeNames.Count],
                    Size = random.Next(50, 450), // Increased max size
                    HeatingType = random.Next(0, 3) switch { 0 => "Electric", 1 => "Gas", _ => "Central" },
                    Location = $"Bulgaria, {random.Next(1000, 9000)}",
                    Address = $"ул. {homeNames[i % homeNames.Count].Replace(" ", "")} {random.Next(1, 100)}", // Simpler address
                    BuildingType = random.Next(0, 3) switch { 0 => "Apartment", 1 => "House", _ => "Townhouse" },
                    InsulationLevel = random.Next(0, 3) switch { 0 => "Low", 1 => "Medium", _ => "High" },
                    YearBuilt = random.Next(1950, currentUtcTime.Year), // Year up to last year
                    Description = aiHomeDescriptions[i % aiHomeDescriptions.Count],
                    LastModified = currentUtcTime
                });
            }

            await _context.Homes.AddRangeAsync(homes);
            await _context.SaveChangesAsync();

            int applianceCount = random.Next(Math.Min(homes.Count * 3, 30), Math.Min(homes.Count * 7, 70)); // 3-7 appliances per home, capped
            var appliances = new List<Appliance>();

            if (homes.Any()) // Ensure homes exist before creating appliances
            {
                for (int i = 0; i < applianceCount; i++)
                {
                    var home = homes[random.Next(homes.Count)];
                    appliances.Add(new Appliance
                    {
                        HomeId = home.HomeId,
                        Name = applianceNames[i % applianceNames.Count],
                        Brand = applianceBrands[random.Next(applianceBrands.Count)],
                        PowerRating = $"{random.Next(100, 3500)}W", // Wider power rating
                        EfficiencyRating = efficiencyRatings[random.Next(efficiencyRatings.Count)],
                        Notes = (random.Next(0, 3) == 0) ? null : aiApplianceNotes[i % aiApplianceNotes.Count],
                        PurchaseDate = (random.Next(0, 2) == 0) ? (DateTime?)null : currentUtcTime.AddDays(-random.Next(1, 365 * 12)).Date, // Max 12 years old
                        IconClass = materialDesignApplianceIcons[random.Next(materialDesignApplianceIcons.Count)],
                        LastModified = currentUtcTime
                    });
                }
                await _context.Appliances.AddRangeAsync(appliances);
                await _context.SaveChangesAsync();
            }


            int usageCount = random.Next(Math.Min(applianceCount * 5, 200), Math.Min(applianceCount * 15, 1000)); // 5-15 usages per appliance, capped
            var usages = new List<Usage>();

            if (appliances.Any()) // Ensure appliances exist
            {
                for (int i = 0; i < usageCount; i++)
                {
                    var appliance = appliances[random.Next(appliances.Count)];
                    usages.Add(new Usage
                    {
                        UserId = user.Id,
                        ApplianceId = appliance.ApplianceId,
                        Date = currentUtcTime.AddDays(-random.Next(1, 90)).Date, // Usage within last 90 days
                        Time = currentUtcTime.AddHours(-random.Next(0, 24)).AddMinutes(-random.Next(0, 60)),
                        EnergyUsed = Math.Round((decimal)(random.NextDouble() * (appliance.PowerRating.Contains("W") ? (double.Parse(Regex.Match(appliance.PowerRating, @"\d+").Value) / 1000.0) : 2.0) * random.NextDouble() * 4), 2), // More realistic energy used based on power rating (up to 4 hours use)
                        UsageFrequency = random.Next(1, 6),
                        ContextNotes = (random.Next(0, 2) == 0) ? null : aiUsageContextNotes[i % aiUsageContextNotes.Count],
                        IconClass = appliance.IconClass
                    });
                }
                await _context.Usages.AddRangeAsync(usages);
                await _context.SaveChangesAsync();
            }

            _logger.LogInformation("Database refilled successfully.");
                return Json(new { success = true, message = "Database refilled with AI-generated detailed data! ✅" });
            }
            catch (Exception ex)
            {
                // Log the full exception with user context if possible
                _logger.LogError(ex, "Error occurred in FillDatabase method");

                // Return a simpler object that ASP.NET Core will serialize to JSON.
                // We'll keep the detailed ex.ToString() out of the client response for brevity and security,
                // relying on server logs for the full details.
                return StatusCode(500, new
                {
                    success = false,
                    message = "An internal server error occurred. Please check server logs for detailed information.",
                    error = ex.Message // Send a concise error message
                });
            }
        }

        private async Task<List<string>> GenerateDataWithAI(string prompt, int maxTokens = 1000) // Added maxTokens parameter
        {
            var generatedItems = new List<string>();
            try
            {
                var apiKey = _configuration["OpenAI:ApiKey"];
                if (string.IsNullOrEmpty(apiKey))
                {
                    _logger.LogError("OpenAI API key is missing. Returning default data for prompt: {Prompt}", prompt);
                    return new List<string> { $"Error: OpenAI API Key Missing. Prompt: {prompt.Substring(0, Math.Min(prompt.Length, 50))}" };
                }

                var openAiApi = new OpenAIAPI(apiKey);
                var chatRequest = new ChatRequest
                {
                    Model = "gpt-3.5-turbo", // Consider gpt-3.5-turbo-instruct or others if better for generation
                    Messages = new[]
                    {
                        new ChatMessage(ChatMessageRole.System, "You are an assistant that generates lists of unique items. Each item should be on a new line. Do NOT include numbers, bullet points, or any other extra text unless specifically requested in the prompt. Be creative and adhere to the user's request for content and style."),
                        new ChatMessage(ChatMessageRole.User, prompt)
                    },
                    MaxTokens = maxTokens, // Use the passed maxTokens
                    Temperature = 0.7 // A bit of creativity
                };

                var chatResult = await openAiApi.Chat.CreateChatCompletionAsync(chatRequest);
                if (chatResult?.Choices?.Count > 0 && chatResult.Choices[0].Message != null)
                {
                    string response = chatResult.Choices[0].Message.TextContent.Trim();
                    generatedItems = response.Split('\n', StringSplitOptions.RemoveEmptyEntries)
                                           .Select(item => item.Trim())
                                           .Where(item => !string.IsNullOrWhiteSpace(item))
                                           .Select(item => Regex.Replace(item, @"^\s*\d+\.\s*", "")) // Remove potential leading numbers/bullets
                                           .Distinct() // Ensure uniqueness within this batch
                                           .ToList();

                    if (!generatedItems.Any())
                    {
                        _logger.LogWarning("AI returned an empty or unparsable list for prompt: {Prompt}. Response: {ResponseText}", prompt, response);
                        generatedItems.Add($"Default Item (AI Error for prompt: {prompt.Substring(0, Math.Min(prompt.Length, 50))})");
                    }
                }
                else
                {
                    _logger.LogWarning("AI returned no valid choices or message for prompt: {Prompt}. Full response: {FullResponse}", prompt, chatResult?.ToString());
                    generatedItems.Add($"Default Item (AI No Choice for prompt: {prompt.Substring(0, Math.Min(prompt.Length, 50))})");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving AI-generated data for prompt '{Prompt}'.", prompt);
                generatedItems.Add($"Error: Exception during AI generation. Prompt: {prompt.Substring(0, Math.Min(prompt.Length, 50))}");
            }

            // Log a sample of what was generated
            if (generatedItems.Any())
            {
                _logger.LogInformation("AI generated {Count} items for prompt '{PromptStart}...'. First item: {FirstItem}", generatedItems.Count, prompt.Substring(0, Math.Min(prompt.Length, 30)), generatedItems.First().Substring(0, Math.Min(generatedItems.First().Length, 70)));
            }
            else
            {
                _logger.LogWarning("AI generation resulted in zero items for prompt: {Prompt}", prompt);
            }

            return generatedItems;
        }



        [HttpPost]
        public async Task<IActionResult> ToggleSimulation(bool enable, int interval)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            using var scope = _context;

            user.IsSimulationEnabled = enable;
            user.SelectedSimulationInterval = interval;

            await _context.SaveChangesAsync();

            return Json(new { success = true, message = enable ? "Simulation started." : "Simulation stopped." });
        }


        [HttpPost]
        public async Task<IActionResult> UpdateSimulationInterval(int interval)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            user.SelectedSimulationInterval = interval;

            await _context.SaveChangesAsync();

            return Json(new { success = true, message = $"Interval updated to {interval}s." });
        }


        [HttpGet]
        public async Task<IActionResult> GetSimulationState()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            return Json(new
            {
                success = true,
                isRunning = user.IsSimulationEnabled,
                interval = user.SelectedSimulationInterval
            });
        }


    }
}
